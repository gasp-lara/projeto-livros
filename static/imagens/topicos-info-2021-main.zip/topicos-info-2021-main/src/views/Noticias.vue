<template>
    <v-row>
        <v-col cols="12" sm="6" md="4">
            <v-card>Notícia 1</v-card>
            
        </v-col>

        <v-col cols="12" sm="6" md="4">
            <v-card>Notícia 2</v-card>
        </v-col>

        <v-col cols="12" sm="6" md="4">
            <v-card>Notícia 3</v-card>
        </v-col>
    </v-row>
</template>

<script>
export default {

}
</script>

<style>

</style>